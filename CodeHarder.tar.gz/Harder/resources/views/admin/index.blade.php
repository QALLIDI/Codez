@extends('main')

@section('title' , ' Admin Panel')

@section('content')

<div class="container">
@include('partials._sidebar')
</div>

@endsection
