@extends('main')

@section('title','Contact Us')

@section('content')

<div class="container">
         <div class="row">
      <div class="col s12">    
    <div class="card-panel grey white-text"><i class="material-icons left">settings_ethernet</i>Code<b>Harder</b> is an Open Source Web Site for Coders and Devloppers who needs help in any programming language .</div>        
      </div>
      <div class="col s12">
      <div class="card-panel blue white-text"><i class="material-icons left">email</i>Send Your Message</div>
      <div class="card-panel">
          <span class="blue-text">
 <div class="row">
    <form class="col s8">
      <div class="row">
        <div class="input-field col s12">
          <input id="email" type="email" class="validate">
          <label for="email" data-error="wrong" data-success="right">Email</label>
        </div>
      </div>
      <div class="row">
       <label for="textarea1">Message</label> 
        <div class="input-field col s12">   
        </div><textarea id="textarea1" class="materialize-textarea"></textarea>
      </div>
      <button class="btn waves-effect waves-light blue" type="submit" name="action">Send Your Message
    <i class="material-icons right">send</i>
  </button>
    </form>
  </div> 
          </span>
    </div>
      </div>
    </div>

</div>
  @endsection     