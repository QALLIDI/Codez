@extends('main')

@section('title' , ' Membres')

@section('content')
<div class="row">
  <div class="col s12">
<div class="card-panel black white-text"><i class="material-icons left">settings_ethernet</i>Code<b>Harder</b> is an Open Source Web Site for Coders and Devloppers who needs help in any programming language .</div>
@if (count($errors) > 0)
    <div class="card-panel red white-text"><i class="material-icons left">error</i>
    <br />
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
  </div>
  <div class="col s7">
    <div class="row">
         <div class="col s12">
           <div class="card-panel">
             <span class="black-text">
               <div class="card-panel blue white-text"><i class="material-icons left">group_add</i>Subscribe on our Website in order to become one of our Coders !</div>
               <!-- Login Form -->
               {!! Form::open(['route' => 'subscribe.store']) !!}
                  <div class="row">
                    <div class="row">
                     <div class="input-field col s6">
                       {{Form::label('firstname','First Name')}}
                       {{Form::text('firstname',null,array('class' => 'validate'))}}
                       </div>
                       <div class="input-field col s6">
                       {{Form::label('lastname','Last Name')}}
                       {{Form::text('lastname',null,array('class' => 'validate'))}}
                       </div>
                    </div>
                       <div class="input-field col s9">
                       {{Form::label('email','Email')}}
                       {{Form::email('email',null,array('class' => 'validate'))}}
                       </div>
                       <div class="input-field col s9">
                       {{Form::label('pseudo','Pseudo')}}
                       {{Form::text('pseudo',null,array('class' => 'validate'))}}
                       </div>
                       <div class="input-field col s6">
                       {{Form::label('password','Password')}}
                       {{Form::password('password',null,array('class' => 'validate'))}}
                       </div>
                       <div class="input-field col s6">
                       {{Form::label('password','Password (Validation) :')}}
                       {{Form::password('password1',null,array('class' => 'validate'))}}
                       </div>
                       <div class="input-field col s7">
                       {{Form::label('phone','Phone Number')}}
                       {{Form::text('phone',null,array('class' => 'validate'))}}
                       </div>
                       <div class="input-field col s8">
                       <div class="file-field input-field">
                        <div class="btn blue">
                            <i class="Meduim material-icons">photo</i>
                            <input type="file" name="image">
                       </div>
                          <div class="file-path-wrapper">
                          <input class="file-path validate" type="text" name="image">
                          </div>
                       </div>
                       </div>
                  </div>
                 {{Form::submit('Subscribe',array('class' => 'btn waves-effect waves-light blue'))}}
                 {!! Form::close() !!}
               <!-- End Form -->
             </span>
           </div>
         </div>
       </div>
  </div>
  <div class="col s5">
    <div class="row">
         <div class="col s12">
           <div class="card-panel">
             <span class="black-text">
               <div class="card-panel blue white-text"><i class="material-icons left">lock</i>Enter your email and your password here !</div>
               <!-- Login Form -->
               {!! Form::open(['route' => 'questions.store']) !!}
                     <div class="row">
                       <div class="input-field col s12">
                       {{Form::label('email','Email')}}
                       {{Form::email('email',null,array('class' => 'validate'))}}
                       </div>
                       <div class="input-field col s8">
                       {{Form::label('password','Password')}}
                       {{Form::password('password',null,array('class' => 'validate'))}}
                       </div>
                     </div>
                 {{Form::submit('Log In',array('class' => 'btn waves-effect waves-light blue'))}}
                 {!! Form::close() !!}
               <!-- End Form -->
             </span>
           </div>
         </div>
       </div>
  </div>
</div>
@endsection
