@extends('main')

@section('title','Coders')
@section('content')
    <div class="row">
      <div class="col s12">
        
    <div class="card-panel grey white-text"><i class="material-icons left">settings_ethernet</i>Code<b>Harder</b> is an Open Source Web Site for Coders and Devloppers who needs help in any programming language .</div>
            
      </div>
      <div class="col s6">

      </div>
      <div class="col s6">

      </div>
    </div>
@endsection   