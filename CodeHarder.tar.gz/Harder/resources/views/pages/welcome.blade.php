@extends('main')

@section('title',' Home')

@section('content')
    <div class="row">
      <div class="col s12">

    <div class="card-panel black white-text"><i class="material-icons left">settings_ethernet</i>Code<b>Harder</b> is an Open Source Web Site for Coders and Devloppers who needs help in any programming language .</div>
      </div>
      <div class="col s12">
        <div class="row">
    <div class="col s12">
      <div class="card">
        <div class="card-image">
          <img src="../img/image.jpg">
        </div>
      </div>
    </div>
  </div>
      </div>
    </div>

@endsection
