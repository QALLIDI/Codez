@extends('main')

@section('title' , "Question ?")

@section('content')

<div class="container">
<div class="row">
      <div class="col s12">
    <div class="card-panel grey white-text"><i class="material-icons left">settings_ethernet</i>Code<b>Harder</b> is an Open Source Web Site for Coders and Developpers who needs help in any programming language .</div>
<!-- Errors -->
@if (count($errors) > 0)
    <div class="card-panel red white-text"><i class="material-icons left">error</i>
    <br />
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
<!-- End Errors -->
      </div>
      <div class="col s12">
      <div class="card-panel blue white-text"><i class="material-icons left">info</i>Your Question ?</div>
        <div class="card-panel">
          <span class="blue-text">
 <div class="row">

<!-- Form -->
{!! Form::open(['route' => 'questions.store']) !!}
      <div class="row">
        <div class="input-field col s4">
        {{Form::label('firstname','First Name')}}
        {{Form::text('firstname',null,array('class' => 'validate'))}}
        </div>
        <div class="input-field col s4">
        {{Form::label('lastname','Last Name')}}
        {{Form::text('lastname',null,array('class' => 'validate'))}}
        </div>
      </div>
      <div class="row">
        <div class="input-field col s8">
        {{Form::label('email','Email')}}
        {{Form::email('email',null,array('class' => 'validate'))}}
        </div>
      </div>
      <div class="row">
        <div class="input-field col s11">
         {{Form::label('question','Question ... ?')}}
         {{Form::text('question',null,array('class' => 'validate'))}}
        </div>
  </div>
  {{Form::submit('Post Your Question',array('class' => 'btn waves-effect waves-light blue'))}}
  {!! Form::close() !!}
<!-- End Form -->
</div>
</span>
</div>
</div>
</div>
</div>

@endsection
