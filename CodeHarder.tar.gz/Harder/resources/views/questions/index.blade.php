@extends('main')

@section('title',' All Questions')

@section('content')

<div class="row">
      <div class="col s12">
    <div class="card-panel black white-text"><i class="material-icons left">settings_ethernet</i>Code<b>Harder</b> is an Open Source Web Site for Coders and Developpers who needs help in any programming language .</div>
      </div>
      <div class="row">
      <div class="col s12">
        <div class="card-panel">
          <span class="black-text">
            <a href="questions/create"><div class="card-panel blue white-text"><i class="material-icons left">edit</i>Question ?</div></a>
          </span>
        </div>
     @if (count($questions) > 0)
            @foreach($questions as $question)
    <div class="row">
    <div class="col s4">
    </div>
      <div class="col s8">
       <div class="chip light-blue accent-4 white-text">
        {{ $question->lastname }} {{ $question->firstname }}
       </div>
       <div class="chip  light-blue accent-3 white-text">
        {{ $question->email }}
       </div>
       <div class="chip  light-blue accent-2 white-text">
        {{ $question->created_at }}
       </div>
      <div class="card-panel grey lighten-3">
         <i class="material-icons">sentiment_very_dissatisfied</i> <span class="black-text">{{ $question->question }}</span>
      </div>
    </div>
      </div>
        @endforeach
     @endif
      </div>
</div>

@endsection
