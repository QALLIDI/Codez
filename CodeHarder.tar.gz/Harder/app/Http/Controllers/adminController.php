<?php

namespace App\Http\Controllers;

class AdminController extends Controller
{
    public function getIndex(){
      return view('admin.index');
    }

    public function getCoders(){
      return view('admin.coders');
    }

    public function getCodes(){
      return view('admin.codes');
    }
}
