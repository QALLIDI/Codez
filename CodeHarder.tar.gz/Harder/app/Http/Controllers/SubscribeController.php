<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Http\Controllers\Controller;

use App\Subscribe;

class SubscribeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        /* Subcribe Table & Validation Method */
        $this->validate($request , array(
          'firstname' => 'required|max:255',
          'lastname'  => 'required|max:255',
          'email'     => 'required|email',
          'pseudo'    => 'required|max:255',
          'password'  => 'required|max:255',
          'phone'     => 'required',
          'image'     => 'required'

        ));

        $subscribe = new Subscribe;

        $subscribe->firstname = $request->firstname ;
        $subscribe->lastname  = $request->lastname  ;
        $subscribe->email     = $request->email     ;
        $subscribe->pseudo    = $request->pseudo    ;
        $subscribe->phone     = $request->phone     ;
        $subscribe->image     = $request->image     ;
        $subscribe->password  = $request->password  ;
        $pass                 = $request->password1 ;

        if(strcmp($pass,$request->password) == 0){

          $subscribe->save();

          if ($validator->fails()) {
             return redirect('membres')
                         ->withErrors($validator)
                         ->withInput();
         }
        }else{
          return redirect('membres');
        }


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
