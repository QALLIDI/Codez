<?php $__env->startSection('title' , "Question ?"); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
<div class="row">
      <div class="col s12">
    <div class="card-panel grey white-text"><i class="material-icons left">settings_ethernet</i>Code<b>Harder</b> is an Open Source Web Site for Coders and Developpers who needs help in any programming language .</div>
<!-- Errors -->
<?php if(count($errors) > 0): ?>
    <div class="card-panel red white-text"><i class="material-icons left">error</i>
    <br />
        <ul>
            <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>
<!-- End Errors -->
      </div>
      <div class="col s12">
      <div class="card-panel blue white-text"><i class="material-icons left">info</i>Your Question ?</div>
        <div class="card-panel">
          <span class="blue-text">
 <div class="row">

<!-- Form -->
<?php echo Form::open(['route' => 'questions.store']); ?>

      <div class="row">
        <div class="input-field col s4">
        <?php echo e(Form::label('firstname','First Name')); ?>

        <?php echo e(Form::text('firstname',null,array('class' => 'validate'))); ?>

        </div>
        <div class="input-field col s4">
        <?php echo e(Form::label('lastname','Last Name')); ?>

        <?php echo e(Form::text('lastname',null,array('class' => 'validate'))); ?>

        </div>
      </div>
      <div class="row">
        <div class="input-field col s8">
        <?php echo e(Form::label('email','Email')); ?>

        <?php echo e(Form::email('email',null,array('class' => 'validate'))); ?>

        </div>
      </div>
      <div class="row">
        <div class="input-field col s11">
         <?php echo e(Form::label('question','Question ... ?')); ?>

         <?php echo e(Form::text('question',null,array('class' => 'validate'))); ?>

        </div>
  </div>
  <?php echo e(Form::submit('Post Your Question',array('class' => 'btn waves-effect waves-light blue'))); ?>

  <?php echo Form::close(); ?>

<!-- End Form -->
</div>
</span>
</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>