

<?php $__env->startSection('title','Codes'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
      <div class="col s12">
    <div class="card-panel black  white-text"><i class="material-icons left">settings_ethernet</i>Code<b>Harder</b> is an Open Source Web Site for Coders and Devloppers who needs help in any programming language .</div>
      </div>

        <div class="col s3">
        <a href="" class="white-text">
          <div class="card-panel blue">
           <span class="white-text"><i class="material-icons left large">settings_ethernet</i>
           <h2>.NET</h2>
           </span>
         </div>
         </a>
        </div>
        <div class="col s3">
        <a href="" class="white-text">
          <div class="card-panel green accent-3">
           <span class="white-text"><i class="material-icons left large">settings_ethernet</i>
           <h2>J2EE</h2>
           </span>
         </div>
         </a>
        </div>
        <div class="col s3">
        <a href="" class="white-text">
          <div class="card-panel yellow">
           <span class="white-text"><i class="material-icons left large">settings_ethernet</i>
           <h2>JS</h2>
           </span>
         </div>
         </a>
        </div>
        <div class="col s3">
        <a href="" class="white-text">
          <div class="card-panel purple">
           <span class="white-text"><i class="material-icons left large">settings_ethernet</i>
           <h2>PHP</h2>
           </span>
         </div>
         </a>
        </div>
         <div class="col s3">
        <a href="" class="white-text">
          <div class="card-panel deep-orange">
           <span class="white-text"><i class="material-icons left large">settings_ethernet</i>
           <h2>C#</h2>
           </span>
         </div>
         </a>
        </div>
         <div class="col s3">
        <a href="" class="white-text">
          <div class="card-panel light-green accent-3">
           <span class="white-text"><i class="material-icons left large">settings_ethernet</i>
           <h2>VB</h2>
           </span>
         </div>
         </a>
        </div>
         <div class="col s3">
        <a href="" class="white-text">
          <div class="card-panel orange">
           <span class="white-text"><i class="material-icons left large">settings_ethernet</i>
           <h2>SQL</h2>
           </span>
         </div>
         </a>
        </div>
         <div class="col s3">
        <a href="" class="white-text">
          <div class="card-panel cyan accent-3">
           <span class="white-text"><i class="material-icons left large">settings_ethernet</i>
           <h2>C++</h2>
           </span>
         </div>
         </a>
        </div>
        <div class="col s3">
        <a href="" class="white-text">
          <div class="card-panel lime accent-4">
           <span class="white-text"><i class="material-icons left large">settings_ethernet</i>
           <h2>JAVA</h2>
           </span>
         </div>
         </a>
        </div>
        <div class="col s3">
        <a href="" class="white-text">
          <div class="card-panel red">
           <span class="white-text"><i class="material-icons left large">settings_ethernet</i>
           <h2>Ruby</h2>
           </span>
         </div>
         </a>
        </div>
        <div class="col s3">
        <a href="" class="white-text">
          <div class="card-panel deep-orange accent-4">
           <span class="white-text"><i class="material-icons left large">settings_ethernet</i>
           <h2>Rails</h2>
           </span>
         </div>
         </a>
        </div>
        <div class="col s3">
        <a href="" class="white-text">
          <div class="card-panel blue-grey">
           <span class="white-text"><i class="material-icons left large">settings_ethernet</i>
           <h2>XML</h2>
           </span>
         </div>
         </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>