<?php $__env->startSection('title' , ' Admin Panel'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
<?php echo $__env->make('partials._sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>