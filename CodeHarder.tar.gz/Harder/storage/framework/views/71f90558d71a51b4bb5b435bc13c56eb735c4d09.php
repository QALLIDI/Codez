<?php $__env->startSection('title',' All Questions'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
      <div class="col s12">
    <div class="card-panel black white-text"><i class="material-icons left">settings_ethernet</i>Code<b>Harder</b> is an Open Source Web Site for Coders and Developpers who needs help in any programming language .</div>
      </div>
      <div class="row">
      <div class="col s12">
        <div class="card-panel">
          <span class="black-text">
            <a href="questions/create"><div class="card-panel blue white-text"><i class="material-icons left">edit</i>Question ?</div></a>
          </span>
        </div>
     <?php if(count($questions) > 0): ?>
            <?php foreach($questions as $question): ?>
    <div class="row">
    <div class="col s4">
    </div>
      <div class="col s8">
       <div class="chip light-blue accent-4 white-text">
        <?php echo e($question->lastname); ?> <?php echo e($question->firstname); ?>

       </div>
       <div class="chip  light-blue accent-3 white-text">
        <?php echo e($question->email); ?>

       </div>
       <div class="chip  light-blue accent-2 white-text">
        <?php echo e($question->created_at); ?>

       </div>
      <div class="card-panel grey lighten-3">
         <i class="material-icons">sentiment_very_dissatisfied</i> <span class="black-text"><?php echo e($question->question); ?></span>
      </div>
    </div>
      </div>
        <?php endforeach; ?>
     <?php endif; ?>
      </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>