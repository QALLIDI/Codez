<?php $__env->startSection('title','About Us'); ?>

<?php $__env->startSection('content'); ?>
         <div class="row">
      <div class="col s12">
        
    <div class="card-panel grey white-text"><i class="material-icons left">settings_ethernet</i>Code<b>Harder</b> is an Open Source Web Site for Coders and Devloppers who needs help in any programming language .</div>
            
      </div>
      <div class="col s6">
      <div class="card-panel blue white-text"><i class="material-icons left">info</i>About Us</div>
        <div class="card-panel grey">
          <span class="white-text">I am a very simple card. I am good at containing small bits of information.
          I am convenient because I require little markup to use effectively. I am similar to what is called a panel in other frameworks.
          </span>
    </div>
      </div>
      <div class="col s6">
      <div class="card-panel blue white-text"><i class="material-icons left">stars</i>Our Goals</div>
      <div class="card-panel grey">
          <span class="white-text">I am a very simple card. I am good at containing small bits of information.
          I am convenient because I require little markup to use effectively. I am similar to what is called a panel in other frameworks.
          </span>
    </div>
    <div class="card-panel grey">
          <span class="white-text">I am a very simple card. I am good at containing small bits of information.
          I am convenient because I require little markup to use effectively. I am similar to what is called a panel in other frameworks.
          </span>
    </div>
    <div class="card-panel grey">
          <span class="white-text">I am a very simple card. I am good at containing small bits of information.
          I am convenient because I require little markup to use effectively. I am similar to what is called a panel in other frameworks.
          </span>
    </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>      
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>