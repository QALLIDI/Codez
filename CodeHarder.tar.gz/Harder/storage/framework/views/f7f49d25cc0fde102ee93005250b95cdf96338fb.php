<footer class="page-footer blue">
          <div class="footer-copyright">
            <div class="container">
            © 2017 Copyright All Rights Reserved .
            <a class="grey-text text-lighten-4 right" href="#!">QALLIDI Mohammed Amine</a>
            </div>
          </div>
</footer>
