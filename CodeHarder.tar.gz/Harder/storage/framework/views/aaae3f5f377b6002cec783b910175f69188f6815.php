<?php $__env->startSection('title' , ' Membres'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col s12">
<div class="card-panel black white-text"><i class="material-icons left">settings_ethernet</i>Code<b>Harder</b> is an Open Source Web Site for Coders and Devloppers who needs help in any programming language .</div>
<?php if(count($errors) > 0): ?>
    <div class="card-panel red white-text"><i class="material-icons left">error</i>
    <br />
        <ul>
            <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>
  </div>
  <div class="col s7">
    <div class="row">
         <div class="col s12">
           <div class="card-panel">
             <span class="black-text">
               <div class="card-panel blue white-text"><i class="material-icons left">group_add</i>Subscribe on our Website in order to become one of our Coders !</div>
               <!-- Login Form -->
               <?php echo Form::open(['route' => 'subscribe.store']); ?>

                  <div class="row">
                    <div class="row">
                     <div class="input-field col s6">
                       <?php echo e(Form::label('firstname','First Name')); ?>

                       <?php echo e(Form::text('firstname',null,array('class' => 'validate'))); ?>

                       </div>
                       <div class="input-field col s6">
                       <?php echo e(Form::label('lastname','Last Name')); ?>

                       <?php echo e(Form::text('lastname',null,array('class' => 'validate'))); ?>

                       </div>
                    </div>
                       <div class="input-field col s9">
                       <?php echo e(Form::label('email','Email')); ?>

                       <?php echo e(Form::email('email',null,array('class' => 'validate'))); ?>

                       </div>
                       <div class="input-field col s9">
                       <?php echo e(Form::label('pseudo','Pseudo')); ?>

                       <?php echo e(Form::text('pseudo',null,array('class' => 'validate'))); ?>

                       </div>
                       <div class="input-field col s6">
                       <?php echo e(Form::label('password','Password')); ?>

                       <?php echo e(Form::password('password',null,array('class' => 'validate'))); ?>

                       </div>
                       <div class="input-field col s6">
                       <?php echo e(Form::label('password','Password (Validation) :')); ?>

                       <?php echo e(Form::password('password1',null,array('class' => 'validate'))); ?>

                       </div>
                       <div class="input-field col s7">
                       <?php echo e(Form::label('phone','Phone Number')); ?>

                       <?php echo e(Form::text('phone',null,array('class' => 'validate'))); ?>

                       </div>
                       <div class="input-field col s8">
                       <div class="file-field input-field">
                        <div class="btn blue">
                            <i class="Meduim material-icons">photo</i>
                            <input type="file" name="image">
                       </div>
                          <div class="file-path-wrapper">
                          <input class="file-path validate" type="text" name="image">
                          </div>
                       </div>
                       </div>
                  </div>
                 <?php echo e(Form::submit('Subscribe',array('class' => 'btn waves-effect waves-light blue'))); ?>

                 <?php echo Form::close(); ?>

               <!-- End Form -->
             </span>
           </div>
         </div>
       </div>
  </div>
  <div class="col s5">
    <div class="row">
         <div class="col s12">
           <div class="card-panel">
             <span class="black-text">
               <div class="card-panel blue white-text"><i class="material-icons left">lock</i>Enter your email and your password here !</div>
               <!-- Login Form -->
               <?php echo Form::open(['route' => 'questions.store']); ?>

                     <div class="row">
                       <div class="input-field col s12">
                       <?php echo e(Form::label('email','Email')); ?>

                       <?php echo e(Form::email('email',null,array('class' => 'validate'))); ?>

                       </div>
                       <div class="input-field col s8">
                       <?php echo e(Form::label('password','Password')); ?>

                       <?php echo e(Form::password('password',null,array('class' => 'validate'))); ?>

                       </div>
                     </div>
                 <?php echo e(Form::submit('Log In',array('class' => 'btn waves-effect waves-light blue'))); ?>

                 <?php echo Form::close(); ?>

               <!-- End Form -->
             </span>
           </div>
         </div>
       </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>