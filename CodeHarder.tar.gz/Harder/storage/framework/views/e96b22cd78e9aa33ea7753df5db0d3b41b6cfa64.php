<nav>
    <div class="nav-wrapper blue-grey lighten-3">
      <ul id="nav-mobile" class="right hide-on-med-and-down">
      </ul>
    </div>
  </nav>
