<nav class="nav-extended">
    <div class="nav-wrapper blue">
      <!-- Logo -->
        <a href="/" class="brand-logo"><i class="material-icons"></i></a>
      <!-- End Logo image -->
      <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
        <li><a href="coders"><i class="material-icons left">local_cafe</i>Coders</a></li>
        <li><a href="codes"><i class="material-icons left">extension</i>Codes</a></li>
        <li><a href="questions"><i class="material-icons left">keyboard</i>Questions</a></li>
        <li><a href="about"><i class="material-icons left">mouse</i>About Us</a></li>
        <li><a href="contact"><i class="material-icons left">email</i>Contact Us</a></li>
        <li><a href="membres"><i class="material-icons left">group</i>Membres</a></li>
      </ul>
      <ul class="side-nav blue" id="mobile-demo">
        <li><a href="coders" class="white-text"><i class="material-icons left">local_cafe</i>Coders</a></li>
        <li><a href="codes" class="white-text"><i class="material-icons left">extension</i>Codes</a></li>
         <li><a href="questions" class="white-text"><i class="material-icons left">keyboard</i>Questions</a></li>
        <li><a href="about" class="white-text"><i class="material-icons left">mouse</i>About Us</a></li>
        <li><a href="contact" class="white-text"><i class="material-icons left">chat</i>Contact Us</a></li>
        <li><a href="membres" class="white-text"><i class="material-icons left">group</i>Membres</a></li>
      </ul>
    </div>
  </nav>
