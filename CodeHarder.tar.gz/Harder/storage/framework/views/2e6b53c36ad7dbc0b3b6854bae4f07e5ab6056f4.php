<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
  <title>CodeHarder - <?php echo $__env->yieldContent('title'); ?></title>
  <?php echo $__env->make('partials._css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>